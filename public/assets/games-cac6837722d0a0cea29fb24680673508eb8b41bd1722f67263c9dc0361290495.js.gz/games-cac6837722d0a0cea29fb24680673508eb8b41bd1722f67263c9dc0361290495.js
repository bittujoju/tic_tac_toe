$('.blank').on('click', function(){
    $(this).hide();
    position = this.id
    $('#' + position + '.first-player').show();
});
